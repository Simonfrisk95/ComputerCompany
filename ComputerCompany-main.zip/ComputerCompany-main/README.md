# ComputerCompany – Lager- och Orderhanteringssystem

## Beskrivning
Detta projekt är ett internt lager- och orderhanteringssystem utvecklat som ett Web API
med ASP.NET Core (.NET 8). Systemet hanterar artiklar, inleveranser, ordrar och användare
och är avsett att användas som backend i ett större system.

## Tekniker
- ASP.NET Core Web API (.NET 8)
- Entity Framework Core
- SQLite
- Swagger / OpenAPI

## Arkitektur
Projektet är uppdelat i tydliga lager:
- Controllers – ansvarar för HTTP-anrop och routing
- Services – innehåller affärslogik
- Repositories – ansvarar för datalagring
- Models – domänmodeller
- Data – DbContext och databasanslutning

## Användarscenarion
1. En lageradministratör skapar och listar artiklar samt ser aktuellt lagersaldo.
2. En användare skapar en order och kan se samt uppdatera orderstatus.
3. Inleveranser registreras och uppdaterar lagersaldot automatiskt.

## Dokumentation
API:t är dokumenterat via Swagger och kan nås på:
http://localhost:5032/swagger



## Kom igång (kör backend)

### Förutsättningar
- .NET SDK 8 installerat

### Starta API
1. Öppna Terminal och gå till API-projektet:
```bash
cd ~/Desktop/ComputerCompany-main/ComputerCompany.API

2. Bygg och starta backend, kör inte dessa bash kommandon samtidigt, utan du ska köra dessa bash kommandon var för sig.
Först: dotnet build
Sedan: dotnet run

Därefter slå in http://localhost:5032/swagger i din webbläsare.

Skulle du vilja stoppa backend (alltså 'swagger'), gör du det genom terminalen, och då trycker du in bara 'Ctrl + C' 

